.. twilio-python documentation master file, created by
   sphinx-quickstart on Fri Jul 27 12:54:05 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


Welcome to twilio-python's documentation!
=========================================

Release v\ |version|.

.. toctree::
   :maxdepth: 2

   README.md


API auto-generated documentation
================================

If you are looking for information on a specific function, class or
method, this part of the documentation is for you.

.. toctree::
   :maxdepth: 1
   :glob:

   docs/source/_rst/modules.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

